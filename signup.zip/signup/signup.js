// import OtherCountry from '@salesforce/schema/Contact.OtherCountry';
import { LightningElement,track } from 'lwc'; 
 
export default class Data extends LightningElement {
    phone = ''
     phoneCode = ''
    otherCountry=''
    showOther = false  
    firstError='' 
    lastError='' 
    emailError='' 
    countryError=''   
    phoneError=''  
   

     columns = [{
        label: 'FirstName',
        fieldName: 'FirstName',
        type: 'text',
        sortable: true
    },
    {
        label: 'LastName', 
        fieldName: 'LastName',  
        type: 'text',
        sortable: true
    },
    {
        label: 'Email',
        fieldName: 'Email',
        type: 'text',
        sortable: true
    },
    {
                label: 'Country',
                fieldName: 'Country',
                type: 'text',
                sortable: true
            },
           
            {
                label: 'Phone',
                fieldName: 'Phone',
                type: 'text',
                sortable: true 
            },
            {
                label: 'Action', 
                fieldName: 'Action',  
                type: 'text',
                sortable: true 
            }, 
            {
                label: 'Action', 
                fieldName: 'Action',  
                type: 'text',
                sortable: true 
            } 
]; 
 
    strFirstName='';
    strLastName='';    
    strEmail='';
    strCountry=''; 
    strPhone='';     
    @track fields =[]; 
    
    firstChangedHandler(event){
        this.strFirstName = event.target.value;  
    }
    lastChangedHandler(event){
        this.strLastName = event.target.value; 
    }
    emailChangedHandler(event){
        this.strEmail = event.target.value;
    } 
   
    countryChangedHandler(event){                                      
        this.strCountry = event.target.value; 
        {
            if (event.target.value === 'Other') {
            this.showOther = true 
            } 
            else {    
               this.showOther = false     
           } 
             this.strCountry =event.target.value  
             
        }                                                                               
    } 
    otherChangedHandler(event){   
        this.otherCountry= event.target.value;
    }
    
         phoneChangedHandler(event){   
            this.strPhone = event.target.value;   
         } 
          
    handleClick(event) 
    {      
     event.preventDefault();    
    
      if(this.otherCountry)  
{
    this.strCountry=this.otherCountry                           
} 
if(this.strCountry==="India")
{
    this.strPhone="+91"+this.strPhone; 
}
 if(this.strCountry==="Australia") 
{
    this.strPhone="+61"+this.strPhone; 
}
 if(this.strCountry==="US") 
{
    this.strPhone="+1"+this.strPhone; 
}
if (this.strCountry==="Singapore") 
{
    this.strPhone="+65"+this.strPhone;  
} 

if (this.strFirstName.length == 0) {                
    this.firstError = 'please fill the input'; 
    fields = false 
} 
else{
    this.firstError = ''
} 
if (this.strLastName.length == 0) {                
    this.lastError = 'please fill the input'; 
    fields = false   
} 
else{
    this.lastError = '' 
}

if (this.strEmail.length == 0) {                 
    this.emailError = 'please fill the input'; 
    fields = false  
} 
else{
    this.emailError = '' 
} 
if (this.strCountry.length == 0) {                
    this.countryError = 'please fill the input'; 
    fields = false  
}                                                        
else{
    this.countryError = '' 
} 

if (this.strPhone.length == 0) {                
    this.phoneError = 'please fill the input'; 
    fields = false  
} 
else{
    this.phoneError = ''     
}

  if(this.strFirstName  &&  this.strLastName  && this.strEmail && this.strCountry  && this.strPhone)
        { 
            this.fields = [...this.fields,{'FirstName' : this.strFirstName, 'LastName' : this.strLastName, 'Email' : this.strEmail,'Country' : this.strCountry, 'Phone' : this.strPhone}];   
             
        }   
       
        
    console.log(JSON.parse(JSON.stringify(this.columns)));
        
    console.log(JSON.parse(JSON.stringify(this.fields)));
         


   
        this.strFirstName =''; 
        this.strLastName ='';  
        this.strEmail='';  
        this.strCountry=''; 
        this.strPhone='';    
    
        this.template.querySelectorAll('input').forEach(element => {  
        element.value = null;     
        });     
    }
    


       

    
//          let table=this.template.querySelector(".table"); 
//          let rIndex;    
//           for(var i = 1; i < table.rows.length; i++)                             
//           {                                                                       
//               table.rows[i].onclick = handleEdit()                                               
//               { 
//                   rIndex = this.rowIndex;                                                           
//                   console.log(rIndex);                               
                  
//                   this.template.querySelector(".FirstName").value = this.cells[0].innerHTML; 
//                   this.template.querySelector(".LastName").value = this.cells[1].innerHTML;
//                   this.template.querySelector(".Email").value = this.cells[2].innerHTML;
//                   this.template.querySelector(".country").value = this.cells[3].innerHTML;
//                   this.template.querySelector(".Phone").value = this.cells[4].innerHTML; 

//               };    
//           } 
//         }                   
//   handleEdit() 
// {
//     table.rows[rIndex].cells[0].innerHTML =this.template.querySelector(".FirstName").value;
//     table.rows[rIndex].cells[1].innerHTML =this.template.querySelector(".LastName").value;
//     table.rows[rIndex].cells[2].innerHTML =this.template.querySelector(".Email").value ;
//     table.rows[rIndex].cells[3].innerHTML =this.template.querySelector(".country").value ;
//     table.rows[rIndex].cells[4].innerHTML=this.template.querySelector(".Phone").value; 
// } 

// handleEdit(event)   
// {
//     let fieldId = event.target.dataset.id
//     let field = this.fields.find(field=> field.id === fieldId)
//     this.strFirstName = field.strFirstName 
//     this.strLastName = field.strLastName
//     this.strEmail = field.strEmail  
//     this.strCountry = field.strCountry                                
//     this.strPhone = field.strPhone.slice(2) 
//     if (this.strCountry === 'Other') {
//         this.showOtherCountry = true
//         this.otherCountry = field.strCountry  
//     } else {
//         this.showOtherCountry = false
//     }
    
// }

} 

